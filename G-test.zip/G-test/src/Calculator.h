#pragma once
#include <string>
#include <stdexcept>
#include <cmath>

// My first Calculator class for Google Test assignment
// I'm learning how to write unit tests!
class Calculator {
public:
    // TODO: Need to test this function - assignment says test positive, negative, and zero
    // This function adds two numbers together
    int add(int a, int b) {
        return a + b; // Simple addition
    }
    
    // TODO: Test normal cases and division by zero (this should be a negative test)
    // Division function - need to handle divide by zero error
    double divide(int dividend, int divisor) {
        if (divisor == 0) {
            throw std::invalid_argument("Division by zero is not allowed"); // Learned this from online example
        }
        return static_cast<double>(dividend) / divisor; // Cast to double for decimal results
    }
    
    // TODO: Test with positive, negative, and zero
    // Square function - multiply number by itself
    int square(int number) {
        return number * number; // This should work for all numbers
    }
    
    // TODO: Test positive numbers and negative numbers (negative test - should throw error)
    // Square root function - only works for positive numbers
    double squareRoot(double number) {
        if (number < 0) {
            throw std::invalid_argument("Cannot calculate square root of negative number"); // Error for negative
        }
        return std::sqrt(number); // Using math library
    }
    
    // TODO: Test various cases including edge cases (not sure what edge cases means exactly)
    // Check if number is positive
    bool isPositive(int number) {
        return number > 0; // Greater than zero means positive
    }
    
    // TODO: Test even numbers, odd numbers, and zero
    // Check if number is even
    bool isEven(int number) {
        return number % 2 == 0; // Modulo 2 equals 0 means even
    }
    
    // TODO: Test with valid and invalid ranges (negative test for negative numbers)
    // Factorial function - learned this is n! = n * (n-1) * (n-2) * ... * 1
    long long factorial(int n) {
        if (n < 0) {
            throw std::invalid_argument("Factorial is not defined for negative numbers"); // Can't do factorial of negative
        }
        if (n == 0 || n == 1) {
            return 1; // Base cases
        }
        long long result = 1;
        for (int i = 2; i <= n; ++i) { // Loop from 2 to n
            result *= i; // Multiply each number
        }
        return result;
    }
    
    // TODO: Test with valid ranges and boundary conditions (still learning what boundary conditions are)
    // Absolute value function
    int absoluteValue(int number) {
        return number < 0 ? -number : number; // If negative, make positive
    }
    
    // TODO: Test with various string inputs including empty strings
    // Get length of a string
    size_t stringLength(const std::string& str) {
        return str.length(); // Built-in string function
    }
    
    // TODO: Test with valid and invalid inputs (not sure what's invalid for strings)
    // Check if string is empty
    bool isEmpty(const std::string& str) {
        return str.empty(); // Built-in empty function
    }
};
