# Copilot Instructions

<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

## Project Overview
This is a C++ Google Test unit testing framework project that demonstrates:
- Comprehensive unit testing with 13 test cases
- Both positive and negative test scenarios
- Industry standard best practices for C++ development
- Proper use of Google Test ASSERT and EXPECT macros

## Code Style Guidelines
- Use descriptive test names that reflect the test purpose (e.g., `EnsureNumberIsPositive`)
- Follow C++ naming conventions (PascalCase for classes, camelCase for functions)
- Include inline comments explaining complex logic
- Use ASSERT for critical failures that should terminate the test
- Use EXPECT for failures that should be logged but allow test continuation

## Testing Guidelines
- Each test must explicitly prove the defined condition
- Include at least 2 negative tests that verify error handling
- Leverage C++ standard library capabilities where appropriate
- Ensure comprehensive coverage of both success and failure scenarios
