#include <gtest/gtest.h>
#include "../src/Calculator.h"
#include <stdexcept>

// This is my first Google Test project!
// Assignment: Create 13 unit tests (11 defined + 2 I need to create)
// Need at least 2 negative tests

// Test fixture class - learned this from Google Test tutorial
class CalculatorTest : public ::testing::Test {
protected:
    void SetUp() override {
        // Create new calculator for each test
        calculator = new Calculator();
    }
    
    void TearDown() override {
        // Clean up memory
        delete calculator;
    }
    
    Calculator* calculator; // Pointer to calculator object
};

// Test 1: Testing addition with positive numbers
// This should pass if my add function works correctly
TEST_F(CalculatorTest, EnsureAdditionWorksWithPositiveNumbers) {
    // Testing different positive number combinations
    EXPECT_EQ(calculator->add(2, 3), 5);
    EXPECT_EQ(calculator->add(10, 15), 25);
    EXPECT_EQ(calculator->add(1, 1), 2);
    
    // Using ASSERT for the most important test case
    ASSERT_EQ(calculator->add(100, 200), 300);
}

// Test 2: Testing addition with negative numbers and zero
// Need to make sure negatives work too
TEST_F(CalculatorTest, EnsureAdditionWorksWithNegativeNumbersAndZero) {
    EXPECT_EQ(calculator->add(-5, -3), -8);  // Two negatives
    EXPECT_EQ(calculator->add(-10, 5), -5);  // Mixed positive and negative
    EXPECT_EQ(calculator->add(0, 0), 0);     // Zero plus zero
    EXPECT_EQ(calculator->add(0, 10), 10);   // Zero plus positive
    
    // Another important test
    ASSERT_EQ(calculator->add(-15, 10), -5);
}

// Test 3: Testing division with normal inputs
// Division should work with regular numbers
TEST_F(CalculatorTest, EnsureDivisionWorksWithValidInputs) {
    EXPECT_DOUBLE_EQ(calculator->divide(10, 2), 5.0);
    EXPECT_DOUBLE_EQ(calculator->divide(15, 3), 5.0);
    EXPECT_DOUBLE_EQ(calculator->divide(-10, 2), -5.0);  // Negative dividend
    
    // Testing decimal results
    ASSERT_DOUBLE_EQ(calculator->divide(7, 2), 3.5);
}

// Test 4: NEGATIVE TEST - Division by zero should throw an exception
// This is one of my required negative tests!
TEST_F(CalculatorTest, EnsureDivisionByZeroThrowsException) {
    // These should all throw exceptions
    EXPECT_THROW(calculator->divide(10, 0), std::invalid_argument);
    EXPECT_THROW(calculator->divide(-5, 0), std::invalid_argument);
    EXPECT_THROW(calculator->divide(0, 0), std::invalid_argument);
    
    // Check that the error message is correct
    try {
        calculator->divide(10, 0);
        FAIL() << "Should have thrown an exception!";
    } catch (const std::invalid_argument& e) {
        ASSERT_STREQ(e.what(), "Division by zero is not allowed");
    }
}

// Test 5: Testing square function
// Should work for positive, negative, and zero
TEST_F(CalculatorTest, EnsureSquareCalculationWorksCorrectly) {
    EXPECT_EQ(calculator->square(4), 16);     // 4 * 4 = 16
    EXPECT_EQ(calculator->square(-3), 9);     // -3 * -3 = 9 (negative times negative is positive)
    EXPECT_EQ(calculator->square(0), 0);      // 0 * 0 = 0
    EXPECT_EQ(calculator->square(1), 1);      // 1 * 1 = 1
    
    // Testing a bigger number
    ASSERT_EQ(calculator->square(10), 100);
}

// Test 6: Testing square root with positive numbers
// Should work fine with positive numbers
TEST_F(CalculatorTest, EnsureSquareRootWorksForPositiveNumbers) {
    EXPECT_DOUBLE_EQ(calculator->squareRoot(9.0), 3.0);   // sqrt(9) = 3
    EXPECT_DOUBLE_EQ(calculator->squareRoot(16.0), 4.0);  // sqrt(16) = 4
    EXPECT_DOUBLE_EQ(calculator->squareRoot(0.0), 0.0);   // sqrt(0) = 0
    EXPECT_DOUBLE_EQ(calculator->squareRoot(1.0), 1.0);   // sqrt(1) = 1
    
    // Testing decimal square root
    ASSERT_DOUBLE_EQ(calculator->squareRoot(2.25), 1.5);  // sqrt(2.25) = 1.5
}

// Test 7: NEGATIVE TEST - Square root of negative numbers should throw exception
// This is another negative test required by assignment
TEST_F(CalculatorTest, EnsureSquareRootOfNegativeNumberThrowsException) {
    // Can't take square root of negative numbers
    EXPECT_THROW(calculator->squareRoot(-1.0), std::invalid_argument);
    EXPECT_THROW(calculator->squareRoot(-25.0), std::invalid_argument);
    EXPECT_THROW(calculator->squareRoot(-0.1), std::invalid_argument);
    
    // Check error message
    try {
        calculator->squareRoot(-4.0);
        FAIL() << "Should throw exception for negative square root!";
    } catch (const std::invalid_argument& e) {
        ASSERT_STREQ(e.what(), "Cannot calculate square root of negative number");
    }
}

// Test 8: Testing if number is positive
// Should return true for positive numbers, false for zero and negative
TEST_F(CalculatorTest, EnsureNumberPositivityCheckWorksCorrectly) {
    // These should be true
    EXPECT_TRUE(calculator->isPositive(1));
    EXPECT_TRUE(calculator->isPositive(100));
    EXPECT_TRUE(calculator->isPositive(5));
    
    // These should be false
    EXPECT_FALSE(calculator->isPositive(0));    // Zero is not positive
    EXPECT_FALSE(calculator->isPositive(-1));   // Negative numbers are not positive
    EXPECT_FALSE(calculator->isPositive(-100));
    
    // Important boundary tests
    ASSERT_TRUE(calculator->isPositive(1));     // 1 should be positive
    ASSERT_FALSE(calculator->isPositive(0));    // 0 should not be positive
}

// Test 9: Testing even number detection
// Even numbers are divisible by 2
TEST_F(CalculatorTest, EnsureEvenNumberDetectionWorksCorrectly) {
    // These should be even (true)
    EXPECT_TRUE(calculator->isEven(2));
    EXPECT_TRUE(calculator->isEven(0));     // Zero is even
    EXPECT_TRUE(calculator->isEven(-4));    // Negative even numbers
    EXPECT_TRUE(calculator->isEven(100));
    
    // These should be odd (false)
    EXPECT_FALSE(calculator->isEven(1));
    EXPECT_FALSE(calculator->isEven(3));
    EXPECT_FALSE(calculator->isEven(-5));   // Negative odd numbers
    EXPECT_FALSE(calculator->isEven(99));
    
    // Zero should definitely be even
    ASSERT_TRUE(calculator->isEven(0));
}

// Test 10: Testing factorial calculation
// Factorial is n! = n * (n-1) * (n-2) * ... * 1
TEST_F(CalculatorTest, EnsureFactorialCalculationWorksForValidInputs) {
    EXPECT_EQ(calculator->factorial(0), 1);      // 0! = 1 (learned this is special case)
    EXPECT_EQ(calculator->factorial(1), 1);      // 1! = 1
    EXPECT_EQ(calculator->factorial(3), 6);      // 3! = 3*2*1 = 6
    EXPECT_EQ(calculator->factorial(4), 24);     // 4! = 4*3*2*1 = 24
    EXPECT_EQ(calculator->factorial(5), 120);    // 5! = 5*4*3*2*1 = 120
    
    // Testing bigger factorial
    ASSERT_EQ(calculator->factorial(6), 720);    // 6! = 6*5*4*3*2*1 = 720
}

// Test 11: NEGATIVE TEST - Factorial of negative numbers should throw exception
// This is my third negative test (assignment requires at least 2)
TEST_F(CalculatorTest, EnsureFactorialOfNegativeNumberThrowsException) {
    // Factorial doesn't work for negative numbers
    EXPECT_THROW(calculator->factorial(-1), std::invalid_argument);
    EXPECT_THROW(calculator->factorial(-5), std::invalid_argument);
    EXPECT_THROW(calculator->factorial(-100), std::invalid_argument);
    
    // Check the error message
    try {
        calculator->factorial(-3);
        FAIL() << "Should throw exception for negative factorial!";
    } catch (const std::invalid_argument& e) {
        ASSERT_STREQ(e.what(), "Factorial is not defined for negative numbers");
    }
}

// Test 12: Testing absolute value
// Absolute value makes negative numbers positive, leaves positive numbers alone
TEST_F(CalculatorTest, EnsureAbsoluteValueCalculationWorksCorrectly) {
    EXPECT_EQ(calculator->absoluteValue(5), 5);      // Positive stays positive
    EXPECT_EQ(calculator->absoluteValue(-5), 5);     // Negative becomes positive
    EXPECT_EQ(calculator->absoluteValue(0), 0);      // Zero stays zero
    EXPECT_EQ(calculator->absoluteValue(-100), 100); // Big negative becomes positive
    EXPECT_EQ(calculator->absoluteValue(100), 100);  // Big positive stays positive
    
    // Edge cases
    ASSERT_EQ(calculator->absoluteValue(-1), 1);
    ASSERT_EQ(calculator->absoluteValue(1), 1);
}

// Test 13: Testing string operations (this is one of the 2 tests I had to create myself)
// Testing string length and empty string detection
TEST_F(CalculatorTest, EnsureStringOperationsWorkCorrectly) {
    // Testing string length
    EXPECT_EQ(calculator->stringLength("hello"), 5);     // "hello" has 5 characters
    EXPECT_EQ(calculator->stringLength(""), 0);          // Empty string has 0 characters
    EXPECT_EQ(calculator->stringLength("a"), 1);         // Single character
    EXPECT_EQ(calculator->stringLength("Google Test"), 11); // "Google Test" has 11 characters (including space)
    
    // Testing empty string detection
    EXPECT_TRUE(calculator->isEmpty(""));                // Empty string should return true
    EXPECT_FALSE(calculator->isEmpty("hello"));          // Non-empty string should return false
    EXPECT_FALSE(calculator->isEmpty(" "));              // Single space is not empty
    
    // Important tests
    ASSERT_EQ(calculator->stringLength("test"), 4);
    ASSERT_TRUE(calculator->isEmpty(""));
}

// Main function to run all tests
// This initializes Google Test and runs all my test cases
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);  // Initialize Google Test framework
    return RUN_ALL_TESTS();  // Run all the tests I wrote
}
