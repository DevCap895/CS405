// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomApplicationException : public std::exception {
private:
    std::string message;

public:
    explicit CustomApplicationException(const std::string& msg) : message("Custom Application Error: " + msg) {}
    
    const char* what() const noexcept override {
        return message.c_str();
    }
};

bool do_even_more_custom_application_logic()
{
  // Throwing a standard runtime_error exception as requested
  std::cout << "Running Even More Custom Application Logic." << std::endl;
  
  // Simulating an error condition that throws a standard exception
  throw std::runtime_error("Something went wrong in even more custom logic!");

  return true;
}
void do_custom_application_logic()
{
  // Wrapping the call with exception handler that catches std::exception
  std::cout << "Running Custom Application Logic." << std::endl;

  try {
    if(do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& e) {
    // Catching std::exception and displaying message and what()
    std::cout << "Caught std::exception in custom logic: " << e.what() << std::endl;
    // Continuing processing as requested
  }

  // Throwing a custom exception derived from std::exception
  // This will be caught explicitly in main
  throw CustomApplicationException("Custom logic completed with issues");

  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // Throwing std::invalid_argument exception for divide by zero errors
  if (den == 0.0f) {
    throw std::invalid_argument("Division by zero is not allowed");
  }
  return (num / den);
}

void do_division() noexcept
{
  // Creating exception handler to capture ONLY the exception thrown by divide
  float numerator = 10.0f;
  float denominator = 0;

  try {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::invalid_argument& e) {
    // Catching only the specific exception type thrown by divide function
    std::cout << "Caught division exception: " << e.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // Creating exception handlers that catch (in this order):
  // 1. custom exception
  // 2. std::exception  
  // 3. uncaught exception (catch-all)
  // that wraps the whole main function
  try {
    do_division();
    do_custom_application_logic();
  }
  catch (const CustomApplicationException& e) {
    // Catching our custom exception first
    std::cout << "Caught custom exception: " << e.what() << std::endl;
  }
  catch (const std::exception& e) {
    // Catching any other standard exceptions
    std::cout << "Caught std::exception: " << e.what() << std::endl;
  }
  catch (...) {
    // Catch-all handler for any unhandled exceptions
    std::cout << "Caught unknown exception - this is the catch-all handler" << std::endl;
  }

  std::cout << "Program completed successfully!" << std::endl;
  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu