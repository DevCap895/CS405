// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
  // get lengths now instead of calling the function every time.
  // this would have most likely been inlined by the compiler, but design for perfomance.
  const auto key_length = key.length();
  const auto source_length = source.length();

  // assert that our input data is good
  assert(key_length > 0);
  assert(source_length > 0);

  std::string output = source;

  // loop through the source string char by char
  for (size_t i = 0; i < source_length; ++i)
  {
    // transform each character based on an xor of the key constrained to key length using a mod
    output[i] = static_cast<char>(source[i] ^ key[i % key_length]);
  }

  // our output length must equal our source length
  assert(output.length() == source_length);

  // return the transformed string
  return output;
}

std::string read_file(const std::string& filename)
{
  // Default text (kept as a fallback in case the file can't be opened)
  std::string file_text = "John Q. Smith\nThis is my test string";

  std::ifstream in(filename, std::ios::in);
  if (!in)
  {
    std::cerr << "WARNING: Could not open input file: " << filename
              << ". Using default built-in text.\n";
    return file_text;
  }

  // Read the entire file (including newlines) into file_text
  std::ostringstream buffer;
  buffer << in.rdbuf();
  file_text = buffer.str();

  // Prevent later asserts from failing if the file is empty
  if (file_text.empty())
  {
    std::cerr << "WARNING: Input file is empty: " << filename
              << ". Using default built-in text.\n";
    file_text = "John Q. Smith\nThis is my test string";
  }

  return file_text;
}

std::string get_student_name(const std::string& string_data)
{
  std::string student_name;

  // find the first newline
  size_t pos = string_data.find('\n');
  // did we find a newline
  if (pos != std::string::npos)
  { // we did, so copy that substring as the student name
    student_name = string_data.substr(0, pos);
  }

  return student_name;
}

void save_data_file(const std::string& filename,
                    const std::string& student_name,
                    const std::string& key,
                    const std::string& data)
{
  std::ofstream out(filename, std::ios::out | std::ios::trunc);
  if (!out)
  {
    std::cerr << "ERROR: Could not open output file for writing: " << filename << "\n";
    return;
  }

  // Create a timestamp (yyyy-mm-dd)
  std::time_t now = std::time(nullptr);
  std::tm local_tm{};

#if defined(_WIN32)
  localtime_s(&local_tm, &now);
#else
  localtime_r(&now, &local_tm);
#endif

  // file format
  // Line 1: student name
  // Line 2: timestamp (yyyy-mm-dd)
  // Line 3: key used
  // Line 4+: data
  out << student_name << "\n";
  out << std::put_time(&local_tm, "%Y-%m-%d") << "\n";
  out << key << "\n";
  out << data;
}

int main()
{
  std::cout << "Encyption Decryption Test!" << std::endl;

  const std::string file_name = "inputdatafile.txt";
  const std::string encrypted_file_name = "encrypteddatafile.txt";
  const std::string decrypted_file_name = "decrytpteddatafile.txt";
  const std::string source_string = read_file(file_name);
  const std::string key = "password";

  // get the student name from the data file
  const std::string student_name = get_student_name(source_string);

  // encrypt sourceString with key
  const std::string encrypted_string = encrypt_decrypt(source_string, key);

  // save encrypted_string to file
  save_data_file(encrypted_file_name, student_name, key, encrypted_string);

  // decrypt encryptedString with key
  const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

  // save decrypted_string to file
  save_data_file(decrypted_file_name, student_name, key, decrypted_string);

  std::cout << "Read File: " << file_name
            << " - Encrypted To: " << encrypted_file_name
            << " - Decrypted To: " << decrypted_file_name << std::endl;

  // students submit input file, encrypted file, decrypted file, source code file, and key used
}